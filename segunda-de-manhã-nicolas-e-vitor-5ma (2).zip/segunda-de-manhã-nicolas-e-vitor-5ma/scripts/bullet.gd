extends Area2D

@export var speed = 600.0

var damage = 25

func _physics_process(delta: float) -> void:
	
	position += transform.x * speed * delta
	
	pass
	
