extends Node2D
@export var enemy_scene : PackedScene
@onready var timer = $Timer
var time = 0.0


func _ready() -> void:
	timer.wait_time = 2.0
	timer.start()
	
func _on_timer_timeout() -> void:
	timer.wait_time = randf_range(0.5, 3.0)
	var enemy = enemy_scene.instantiate()
	
	var direction = Vector2(randf_range(-1, 1) , randf_range(-1, 1)).normalized()
	
	enemy.global_position = get_tree().get_first_node_in_group("player").global_position + (direction * 200)
	
	get_tree().current_scene.add_child(enemy)
		
		
	pass
