extends CharacterBody2D


@export var speed = 40
var is_alive = true
var direction = Vector2.ZERO

@onready var anim_sprite = $AnimatedSprite2D


func _physics_process(delta: float) -> void:
	
	if is_alive:
		move()
		anim()
	
pass
	
func move():
	
	direction = Input.get_vector("left", "right" , "up" , "down")
	
	if direction != Vector2.ZERO:
		velocity = direction * speed
	else:
		velocity = velocity.move_toward(direction, speed)
		
	move_and_slide()
	
	
	pass


func anim():
	
	if direction == Vector2.ZERO:
		anim_sprite.play("idle")
	else:
		if abs(direction.x) > abs(direction.y):
			anim_sprite.play("walk_side")
			if direction.x <0:
				anim_sprite.flip_h = true
			else:
				anim_sprite.flip_h = false
		elif direction.y > 0:
			anim_sprite.play("walk_down")
		else:
			anim_sprite.play("walk_up")	
	
func die ():
	is_alive = false
	anim_sprite.play("death")
	$Area2D.queue_free()
	await get_tree().create_timer(3.0).timeout
	get_tree().reload_current_scene()	
	pass
