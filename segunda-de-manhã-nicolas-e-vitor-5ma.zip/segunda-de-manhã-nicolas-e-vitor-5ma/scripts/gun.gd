extends Node2D

@onready var sprite = $Sprite2D

@export var bullet_scene: PackedScene

func _process(delta: float) -> void:
	
	aim()
	shoot()
	
	pass

func aim():
	
	look_at(get_global_mouse_position())
	
	sprite.flip_v = get_global_mouse_position().x < global_position.x
	
	pass
	
func shoot():
	if Input.is_action_just_pressed("shoot") and bullet_scene:
		
		var bullet = bullet_scene.instantiate()
		
		get_tree().current_scene.add_child(bullet)
		
		bullet.global_position = $Bullet_Pos.global_position
		bullet.global_rotation = global_rotation	
	
	
	pass
