extends CharacterBody2D


@export var speed = 40
var direction = Vector2.ZERO

@onready var anim_sprite = $AnimatedSprite2D


func _physics_process(delta: float) -> void:
	
	move()
	anim()
	pass
	
func move():
	
	direction = Input.get_vector("left", "right" , "up" , "down")
	
	if direction != Vector2.ZERO:
		velocity = direction * speed
	else:
		velocity = velocity.move_toward(Vector2.ZERO, speed)
		
	move_and_slide()
	
	
	pass


func anim():
	
	if direction == Vector2.ZERO:
		anim_sprite.play("idle")
	else:
		if abs(direction.x) > abs(direction.y):
			anim_sprite.play("walk_side")
			if direction.x <0:
				anim_sprite.flip_h = true
			else:
				anim_sprite.flip_h = false
		elif direction.y > 0:
			anim_sprite.play("walk_down")
		else:
			anim_sprite.play("walk_up")	
	
	
	pass
